import { Link } from 'react-router-dom'
import Brand from './Brand'
import Icon from '../ui/Icon'
import { services } from '../../data/nav'

const explore = [
  { label: 'À propos', to: '/a-propos' },
  { label: 'Nos Expériences', to: '/nos-experiences' },
  { label: 'Notre Staff', to: '/notre-staff' },
  { label: 'Réalisations', to: '/realisations' },
  { label: 'Actualités', to: '/actualites' },
]

export default function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="footer">
      <div className="footer__accent" aria-hidden="true" />

      <div className="container footer__inner">
        <div className="footer__brandcol">
          <Brand variant="footer" />
          <p className="footer__tagline">
            L&rsquo;ingénierie intelligente au service de vos projets. Des solutions
            techniques, stratégiques et durables pour un avenir plus performant.
          </p>
          <Link to="/contact" className="btn btn--ghost-lime">
            <Icon name="envelope" size={18} />
            <span>Nous contacter</span>
            <Icon name="arrow-right" size={18} className="btn__trailing" />
          </Link>
        </div>

        <nav className="footer__col" aria-label="Nos services">
          <p className="footer__col-title">Nos Services</p>
          <div className="footer__links">
            {services.map((s) => (
              <Link key={s.to} to={s.to}>
                {s.label}
              </Link>
            ))}
          </div>
        </nav>

        <nav className="footer__col" aria-label="Explorer">
          <p className="footer__col-title">Explorer</p>
          <div className="footer__links">
            {explore.map((l) => (
              <Link key={l.to} to={l.to}>
                {l.label}
              </Link>
            ))}
          </div>
        </nav>

        <div className="footer__col">
          <p className="footer__col-title">Contact</p>
          <p className="footer__contact-text">
            Un projet, une question ou un partenariat&nbsp;? Parlons de vos enjeux
            techniques et stratégiques.
          </p>
          <Link to="/contact" className="btn btn--blue">
            <span>Démarrer un projet</span>
            <Icon name="arrow-right" size={18} className="btn__trailing" />
          </Link>
        </div>
      </div>

      <div className="container footer__bottom">
        <p>© {year} S.E.S.S — Smart Engineering &amp; Strategic Solutions. Tous droits réservés.</p>
        <div className="footer__legal">
          <Link to="/mentions-legales">Mentions légales</Link>
          <Link to="/confidentialite">Confidentialité</Link>
        </div>
      </div>
    </footer>
  )
}
