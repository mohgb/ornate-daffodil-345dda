import { useRef } from 'react'
import Icon from '../ui/Icon'
import { useScrollScene } from '../../lib/useScrollScene'
import { revealUp, countUp } from '../../lib/motion'
import { stats } from '../../data/home'

export default function StatsPanel() {
  const scope = useRef(null)

  useScrollScene(scope, () => {
    revealUp('[data-stat]', { trigger: scope.current, stagger: 0.1, y: 28 })
    scope.current.querySelectorAll('[data-count]').forEach((el) => {
      const end = Number(el.dataset.count)
      countUp(el, end, { suffix: el.dataset.suffix || '' })
    })
  }, [])

  return (
    <section className="section stats" ref={scope} aria-labelledby="stats-title">
      <span className="u-glow-blue stats__glow" aria-hidden="true" />
      <div className="container">
        <header className="stats__header">
          <h2 id="stats-title" className="stats__title">
            Notre expérience <span className="u-lime">en chiffres</span>
          </h2>
        </header>

        <div className="stats__grid">
          {stats.map((s, i) => (
            <div className="stat" data-stat key={i}>
              <span className="stat__icon">
                <Icon name={s.icon} size={26} />
              </span>
              <p className="stat__value">
                {s.text ? (
                  <span>{s.text}</span>
                ) : (
                  <span data-count={s.value} data-suffix={s.suffix || ''}>
                    0{s.suffix || ''}
                  </span>
                )}
              </p>
              <p className="stat__label">{s.label}</p>
              <p className="stat__sub">{s.sub}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
